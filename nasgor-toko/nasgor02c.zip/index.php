<?php
$appFolder="app";
$coreFolder="core";
/*
=================Jangan edit file ini===============
*/
//error_reporting(1);
include($coreFolder."/core.php");
