<div class="container body1"> 
	 
	<div style="margin:10px 0;"></div>
	<div id="tt" class="easyui-tabs" style="width:900px;height:550px;">
		<div title="Home" style="padding:20px">
			<p>Click the above button to add a new tab panel.</p>
			<?php print_r(sess_data()); ;?>
		</div>
	</div>
</div> 
 
