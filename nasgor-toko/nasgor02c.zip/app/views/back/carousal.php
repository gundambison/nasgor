<div id="myCarousel" class="carousel slide">
  <!-- Indicators -->
  <ol class="carousel-indicators"></ol>
  <div class="carousel-inner">
    <div class="item active">
      <img src="data:image/png;base64," data-src="holder.js/100%x500/auto/#777:#7a7a7a/text:First slide" alt="First slide" />
      <div class="container">
        <div class="carousel-caption">
          <h1>Example headline.</h1>
          <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam
          id dolor id nibh ultricies vehicula ut id elit.</p>
          <p>
            <a class="btn btn-large btn-primary" href="#">Sign up today</a>
          </p>
        </div>
      </div>
    </div>
    <div class="item">
      <img src="data:image/png;base64," data-src="holder.js/100%x500/auto/#777:#7a7a7a/text:Second slide" alt="Second slide" />
      <div class="container">
        <div class="carousel-caption">
          <h1>Another example headline.</h1>
          <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam
          id dolor id nibh ultricies vehicula ut id elit.</p>
          <p>
            <a class="btn btn-large btn-primary" href="#">Learn more</a>
          </p>
        </div>
      </div>
    </div>
    <div class="item">
      <img src="data:image/png;base64," data-src="holder.js/100%x500/auto/#777:#7a7a7a/text:Third slide" alt="Third slide" />
      <div class="container">
        <div class="carousel-caption">
          <h1>One more for good measure.</h1>
          <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam
          id dolor id nibh ultricies vehicula ut id elit.</p>
          <p>
            <a class="btn btn-large btn-primary" href="#">Browse gallery</a>
          </p>
        </div>
      </div>
    </div>
  </div>
  <a class="left carousel-control" href="#myCarousel" data-slide="prev"></a> 
  <a class="right carousel-control" href="#myCarousel" data-slide="next"></a>
  </div>