<?php
$mods=array('database', 'session',
'login');
$lib=array('db'=>'database');