<?php

/*
List Semua Body yang ada di script ini. Default adalah posisi 0
*/
$aBody=array(
'home', 'login',
'suplierList','suplierForm',
'storeList','storeForm',
'customerList','customerForm',
);


/*
halaman Spesial
*/
$aSpesial=array(
"saveSession","loginCheck","welcome",
"suplierData","suplierAction", 
"storeData","storeAction",
"customerData", "customerAction",

);