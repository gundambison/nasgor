Cara Pakai
1. import sql yang ada disini
2. buka app/config
3. edit config2 yg ada didalam.. terutama config
4. kembali ke depan
5. edit httaccess, pastikan yang di buka tepat
6. user :admin, password :admin
