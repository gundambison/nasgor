16 November 2013
memulai tampilan baru, nasgor toko sudah fix dan tidak akan di tambah. Yang berikutnya adalah 
Nasgor 160.. projek membuat program mini dengan Nasgor sebanyak 160!

Cara Pakai
1. import sql yang ada disini
2. buka app/config
3. edit config2 yg ada didalam.. terutama config
4. kembali ke depan
5. edit httaccess, pastikan yang di buka tepat
6. user :admin, password :admin
