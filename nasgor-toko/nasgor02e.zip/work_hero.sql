-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2013 at 01:14 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `work_hero`
--

-- --------------------------------------------------------

--
-- Table structure for table `itemcounter`
--

CREATE TABLE IF NOT EXISTS `itemcounter` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itemcounter`
--

INSERT INTO `itemcounter` (`id`) VALUES
(9);

-- --------------------------------------------------------

--
-- Table structure for table `raja_category`
--

CREATE TABLE IF NOT EXISTS `raja_category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_code` varchar(30) DEFAULT NULL,
  `cat_name` varchar(30) DEFAULT NULL,
  `cat_stat` tinyint(1) DEFAULT NULL,
  `cat_parent` int(11) DEFAULT NULL,
  `cat_detail` text NOT NULL,
  `cat_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=191 ;

--
-- Dumping data for table `raja_category`
--

INSERT INTO `raja_category` (`cat_id`, `cat_code`, `cat_name`, `cat_stat`, `cat_parent`, `cat_detail`, `cat_time`) VALUES
(187, 'NET', 'Networking', 1, 0, '', '2013-11-19 15:02:19'),
(188, 'NETCC', 'Accesoris', 1, 187, '', '2013-11-19 15:09:03'),
(189, 'NETBOS', 'Boster', 0, 187, '', '2013-11-20 16:37:26'),
(190, 'NETETH', 'ETERNETH', 1, 189, 'lklkh', '2013-11-23 05:05:19');

-- --------------------------------------------------------

--
-- Table structure for table `raja_categorydetail`
--

CREATE TABLE IF NOT EXISTS `raja_categorydetail` (
  `catdet_id` int(11) NOT NULL AUTO_INCREMENT,
  `catdet_detail` text COMMENT 'desc, address, contact, etc',
  PRIMARY KEY (`catdet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_counter`
--

CREATE TABLE IF NOT EXISTS `raja_counter` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `raja_counter`
--

INSERT INTO `raja_counter` (`id`) VALUES
(210);

-- --------------------------------------------------------

--
-- Table structure for table `raja_currency`
--

CREATE TABLE IF NOT EXISTS `raja_currency` (
  `cur_id` int(11) NOT NULL AUTO_INCREMENT,
  `cur_name` varchar(31) DEFAULT NULL,
  PRIMARY KEY (`cur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_currencyvalue`
--

CREATE TABLE IF NOT EXISTS `raja_currencyvalue` (
  `curval_id` int(11) NOT NULL AUTO_INCREMENT,
  `curval_cur` int(11) DEFAULT NULL,
  `curval_sale` int(11) DEFAULT NULL,
  `curval_buy` int(11) DEFAULT NULL,
  `curval_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`curval_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_customer`
--

CREATE TABLE IF NOT EXISTS `raja_customer` (
  `cus_id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_code` varchar(20) CHARACTER SET utf16 COLLATE utf16_bin NOT NULL,
  `cus_name` varchar(30) CHARACTER SET utf16 COLLATE utf16_bin NOT NULL,
  `cus_phone` text NOT NULL COMMENT 'pisahkan dengan ;',
  `cus_detail` text CHARACTER SET utf16 COLLATE utf16_bin NOT NULL,
  PRIMARY KEY (`cus_id`),
  UNIQUE KEY `cus_code` (`cus_code`),
  KEY `cus_name` (`cus_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=170 ;

--
-- Dumping data for table `raja_customer`
--

INSERT INTO `raja_customer` (`cus_id`, `cus_code`, `cus_name`, `cus_phone`, `cus_detail`) VALUES
(169, '13101900A5', 'gunawan', '["12124","4124124"]', '');

-- --------------------------------------------------------

--
-- Table structure for table `raja_customeraddress`
--

CREATE TABLE IF NOT EXISTS `raja_customeraddress` (
  `cadr_id` int(11) NOT NULL AUTO_INCREMENT,
  `cadr_cus` int(11) NOT NULL,
  `cadr_address` text CHARACTER SET utf32 COLLATE utf32_bin NOT NULL,
  PRIMARY KEY (`cadr_id`),
  KEY `cadr_cus` (`cadr_cus`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `raja_customeraddress`
--

INSERT INTO `raja_customeraddress` (`cadr_id`, `cadr_cus`, `cadr_address`) VALUES
(24, 169, 0x686f74656c31),
(25, 169, 0x686f74656c33),
(26, 169, 0x736166617366617366736166),
(27, 169, 0x647361646173),
(28, 169, 0x73646173646173),
(29, 169, 0x647364617364736164);

-- --------------------------------------------------------

--
-- Table structure for table `raja_customeraddresscounter`
--

CREATE TABLE IF NOT EXISTS `raja_customeraddresscounter` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `raja_customeraddresscounter`
--

INSERT INTO `raja_customeraddresscounter` (`id`) VALUES
(29);

-- --------------------------------------------------------

--
-- Table structure for table `raja_item`
--

CREATE TABLE IF NOT EXISTS `raja_item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(30) DEFAULT NULL,
  `item_name` varchar(30) DEFAULT NULL,
  `item_stat` varchar(30) DEFAULT NULL,
  `item_price` int(11) DEFAULT NULL,
  `item_disc` int(11) DEFAULT NULL,
  `item_size` varchar(30) DEFAULT NULL,
  `item_stock` int(11) DEFAULT NULL,
  `item_price0` varchar(30) DEFAULT NULL,
  `item_stock0` int(11) DEFAULT NULL,
  `item_store` varchar(30) DEFAULT NULL,
  `item_cat` int(11) DEFAULT NULL,
  `item_merk` varchar(30) DEFAULT NULL,
  `item_hot` int(11) DEFAULT NULL,
  `item_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=211 ;

--
-- Dumping data for table `raja_item`
--

INSERT INTO `raja_item` (`item_id`, `item_code`, `item_name`, `item_stat`, `item_price`, `item_disc`, `item_size`, `item_stock`, `item_price0`, `item_stock0`, `item_store`, `item_cat`, `item_merk`, `item_hot`, `item_time`) VALUES
(210, '45', 'tes', '1', 100000, 0, 'pcs', 0, '0', 0, '1', 187, '192', 0, '2013-11-23 15:16:29');

-- --------------------------------------------------------

--
-- Table structure for table `raja_itemdetail`
--

CREATE TABLE IF NOT EXISTS `raja_itemdetail` (
  `itemdet_id` int(11) NOT NULL AUTO_INCREMENT,
  `itemdet_detail` text COMMENT 'expire, color, pcs, desc, barcode, rak, etc',
  PRIMARY KEY (`itemdet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_kurs`
--

CREATE TABLE IF NOT EXISTS `raja_kurs` (
  `k_id` int(11) NOT NULL AUTO_INCREMENT,
  `k_code` varchar(30) DEFAULT NULL,
  `k_name` varchar(30) DEFAULT NULL,
  `k_stat` varchar(1) DEFAULT '1' COMMENT 'show (1)',
  `k_price` int(11) DEFAULT NULL COMMENT 'harga akan berubah2',
  `k_date` date DEFAULT NULL COMMENT 'tanggal update terakhir',
  `k_source` varchar(30) DEFAULT NULL,
  `k_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`k_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=195 ;

--
-- Dumping data for table `raja_kurs`
--

INSERT INTO `raja_kurs` (`k_id`, `k_code`, `k_name`, `k_stat`, `k_price`, `k_date`, `k_source`, `k_time`) VALUES
(193, 'USD', 'US Dolar', '1', 11000, '2013-11-23', 'mandiri', '2013-11-23 03:42:22'),
(194, 'JPY', 'Yen', '1', 114, '2013-11-23', 'Mandiri', '2013-11-23 00:31:24');

-- --------------------------------------------------------

--
-- Table structure for table `raja_kursdetail`
--

CREATE TABLE IF NOT EXISTS `raja_kursdetail` (
  `kdet_id` int(11) NOT NULL AUTO_INCREMENT,
  `kdet_detail` text COMMENT 'from, more, etc',
  PRIMARY KEY (`kdet_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=195 ;

--
-- Dumping data for table `raja_kursdetail`
--

INSERT INTO `raja_kursdetail` (`kdet_id`, `kdet_detail`) VALUES
(193, '{"from":"Jepang","more":"Amerika Serikat, disingkat dengan AS, atau secara umum dikenal dengan Amerika saja,[catatan 1] adalah sebuah negara republik konstitusional federal yang terdiri dari lima puluh negara bagian dan sebuah distrik federal.[4] Negara ini terletak di bagian tengah Amerika Utara, yang menjadi lokasi dari empat puluh delapan negara bagian yang saling bersebelahan, beserta distrik ibu kota Washington, D.C.. Amerika Serikat diapit oleh Samudera Pasifik dan Atlantik di sebelah barat dan timur, berbatasan dengan Kanada di sebelah utara, dan Meksiko di sebelah selatan. Dua negara bagian lainnya, yaitu Alaska dan Hawaii, terletak terpisah dari dataran utama Amerika Serikat. Negara bagian Alaska terletak di sebelah ujung barat laut Amerika Utara, berbatasan dengan Kanada di sebelah timur dan Rusia di sebelah barat, yang dipisahkan oleh Selat Bering. Sedangkan negara bagian Hawaii adalah sebuah kepulauan yang berlokasi di Samudera Pasifik. Amerika Serikat juga memiliki beberapa teritori di Pasifik dan Karibia. Dengan luas wilayah 3,79  juta mil persegi (9,83 juta km2) dan jumlah penduduk sebanyak 315 juta jiwa, Amerika Serikat merupakan negara terluas ketiga atau keempat di dunia, dan terbesar ketiga menurut jumlah penduduk. Amerika Serikat adalah salah satu negara yang paling multi-etnis dan paling multi-kultural di dunia, yang muncul akibat adanya imigrasi besar-besaran dari berbagai penjuru dunia.[8] Iklim dan geografi Amerika Serikat juga sangat beragam dan negara ini menjadi tempat tinggal bagi berbagai spesies."}'),
(194, '{"from":"Jepang","more":"Jepang (bahasa Jepang: \\u65e5\\u672c Nippon\\/Nihon, nama resmi: \\u65e5\\u672c\\u56fd Nipponkoku\\/Nihonkoku Tentang suara ini dengarkan (bantuan\\u00b7info)) adalah sebuah negara kepulauan di Asia Timur. Letaknya di ujung barat Samudra Pasifik, di sebelah timur Laut Jepang, dan bertetangga dengan Republik Rakyat Cina, Korea, dan Rusia. Pulau-pulau paling utara berada di Laut Okhotsk, dan wilayah paling selatan berupa kelompok pulau-pulau kecil di Laut Cina Timur, tepatnya di sebelah selatan Okinawa yang bertetangga dengan Taiwan."}');

-- --------------------------------------------------------

--
-- Table structure for table `raja_kurslog`
--

CREATE TABLE IF NOT EXISTS `raja_kurslog` (
  `log_id` int(11) NOT NULL,
  `log_kurs` int(11) NOT NULL,
  `log_price` int(11) NOT NULL,
  `log_date` date NOT NULL,
  `log_user` int(11) NOT NULL,
  `log_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `raja_kurslog`
--

INSERT INTO `raja_kurslog` (`log_id`, `log_kurs`, `log_price`, `log_date`, `log_user`, `log_time`) VALUES
(195, 194, 0, '0000-00-00', 1, '2013-11-23 02:33:10'),
(196, 194, 0, '0000-00-00', 1, '2013-11-23 02:33:17'),
(197, 193, 0, '0000-00-00', 1, '2013-11-23 03:35:05'),
(200, 193, 0, '2013-11-23', 1, '2013-11-23 03:37:37'),
(204, 193, 0, '2013-11-23', 1, '2013-11-23 03:39:58'),
(205, 193, 0, '2013-11-23', 1, '2013-11-23 03:40:33'),
(206, 193, 0, '2013-11-23', 1, '2013-11-23 03:40:34'),
(207, 193, 0, '2013-11-23', 1, '2013-11-23 03:41:09'),
(208, 193, 0, '2013-11-23', 1, '2013-11-23 03:42:00'),
(209, 193, 0, '2013-11-23', 1, '2013-11-23 03:42:22');

-- --------------------------------------------------------

--
-- Table structure for table `raja_logstock`
--

CREATE TABLE IF NOT EXISTS `raja_logstock` (
  `logstock_id` int(11) NOT NULL AUTO_INCREMENT,
  `logstock_prod` int(11) DEFAULT NULL,
  `logstock_store` int(11) DEFAULT NULL,
  `logstock_stock0` int(11) DEFAULT NULL,
  `logstock_stock1` int(11) DEFAULT NULL,
  `logstock_act` varchar(31) DEFAULT NULL,
  `logstock_type` varchar(31) DEFAULT NULL,
  `logstock_detail` text,
  PRIMARY KEY (`logstock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_merk`
--

CREATE TABLE IF NOT EXISTS `raja_merk` (
  `merk_id` int(11) NOT NULL AUTO_INCREMENT,
  `merk_code` varchar(30) DEFAULT NULL,
  `merk_name` varchar(30) DEFAULT NULL,
  `merk_stat` varchar(30) DEFAULT NULL,
  `merk_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`merk_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=193 ;

--
-- Dumping data for table `raja_merk`
--

INSERT INTO `raja_merk` (`merk_id`, `merk_code`, `merk_name`, `merk_stat`, `merk_time`) VALUES
(192, 'Fuji', 'Fuji film', '1', '2013-11-23 04:48:30'),
(191, 'F', 'Failxxx x x x', '0', '2013-11-20 15:41:22');

-- --------------------------------------------------------

--
-- Table structure for table `raja_merkdetail`
--

CREATE TABLE IF NOT EXISTS `raja_merkdetail` (
  `merkdet_id` int(11) NOT NULL AUTO_INCREMENT,
  `merkdet_detail` text COMMENT 'desc, address, contact, etc',
  PRIMARY KEY (`merkdet_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=193 ;

--
-- Dumping data for table `raja_merkdetail`
--

INSERT INTO `raja_merkdetail` (`merkdet_id`, `merkdet_detail`) VALUES
(191, '{"desc":"-3fas","address":"-dsdsadsad","contact":"23123A"}'),
(192, '{"desc":"-3fas","address":"-dsdsadsad","contact":"21312412"}');

-- --------------------------------------------------------

--
-- Table structure for table `raja_payment`
--

CREATE TABLE IF NOT EXISTS `raja_payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_code` varchar(30) DEFAULT NULL,
  `payment_sales` int(11) DEFAULT NULL,
  `payment_nama` varchar(30) DEFAULT NULL,
  `payment_payto` int(11) DEFAULT NULL,
  `payment_value` int(11) DEFAULT NULL,
  `payment_create` varchar(30) DEFAULT NULL,
  `payment_stat` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_paymentdetail`
--

CREATE TABLE IF NOT EXISTS `raja_paymentdetail` (
  `paymentdet_id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentdet_detail` text COMMENT 'Keterangan, etc',
  PRIMARY KEY (`paymentdet_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_permission`
--

CREATE TABLE IF NOT EXISTS `raja_permission` (
  `per_id` int(11) NOT NULL AUTO_INCREMENT,
  `per_name` varchar(20) NOT NULL,
  `per_detail` text NOT NULL,
  PRIMARY KEY (`per_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `raja_permission`
--

INSERT INTO `raja_permission` (`per_id`, `per_name`, `per_detail`) VALUES
(1, 'master file', ''),
(2, 'produk', ''),
(3, 'invoice', ''),
(4, 'report', ''),
(5, 'utility', ''),
(6, 'history', ''),
(7, 'customer', ''),
(8, 'kurs', ''),
(9, 'stock', ''),
(10, 'stock transfer', ''),
(11, 'sales', ''),
(12, 'purchase', ''),
(13, 'retur sales', ''),
(14, 'retur purchase', ''),
(15, 'repair', '');

-- --------------------------------------------------------

--
-- Table structure for table `raja_product`
--

CREATE TABLE IF NOT EXISTS `raja_product` (
  `prod_id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_code` varchar(9) CHARACTER SET utf32 COLLATE utf32_bin NOT NULL,
  `prod_name` varchar(30) CHARACTER SET utf32 COLLATE utf32_bin NOT NULL,
  `prod_parent` int(11) DEFAULT NULL,
  `prod_merk` int(11) DEFAULT NULL,
  `prod_price` int(11) DEFAULT NULL,
  `prod_stat` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`prod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_productcat`
--

CREATE TABLE IF NOT EXISTS `raja_productcat` (
  `pcat_id` int(11) NOT NULL AUTO_INCREMENT,
  `pcat_prod` int(11) DEFAULT NULL,
  `pcat_cat` int(11) DEFAULT NULL,
  PRIMARY KEY (`pcat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_productdetail`
--

CREATE TABLE IF NOT EXISTS `raja_productdetail` (
  `prodet_id` int(11) NOT NULL AUTO_INCREMENT,
  `prodet_detail` text CHARACTER SET utf32 COLLATE utf32_bin NOT NULL,
  PRIMARY KEY (`prodet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_productprice`
--

CREATE TABLE IF NOT EXISTS `raja_productprice` (
  `prodprice_id` int(11) NOT NULL AUTO_INCREMENT,
  `prodprice_product` int(11) DEFAULT NULL,
  `prodprice_currency` int(11) DEFAULT NULL,
  `prodprice_price` int(11) DEFAULT NULL,
  PRIMARY KEY (`prodprice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_productstock`
--

CREATE TABLE IF NOT EXISTS `raja_productstock` (
  `pstock_id` int(11) NOT NULL AUTO_INCREMENT,
  `pstock_prod` int(11) DEFAULT NULL,
  `pstock_store` int(11) DEFAULT NULL,
  `pstock_stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`pstock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_sales`
--

CREATE TABLE IF NOT EXISTS `raja_sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_code` varchar(30) DEFAULT NULL,
  `sales_customer` int(11) DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `sales_shipp` int(11) DEFAULT NULL,
  `sales_cost` int(11) DEFAULT NULL,
  `sales_total` int(11) DEFAULT NULL,
  `sales_weight` int(11) DEFAULT NULL,
  `sales_stat` int(11) DEFAULT NULL,
  `sales_payto` int(11) DEFAULT NULL,
  `sales_sendby` int(11) DEFAULT NULL,
  `sales_type` int(11) DEFAULT NULL,
  `sales_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sales_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_salesdetail`
--

CREATE TABLE IF NOT EXISTS `raja_salesdetail` (
  `salesdet_id` int(11) NOT NULL AUTO_INCREMENT,
  `salesdet_detail` text COMMENT 'Keterangan, Address, City, CityCode, SendBy, Pricekg, Discount, Message, adminnote, etc',
  PRIMARY KEY (`salesdet_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `raja_store`
--

CREATE TABLE IF NOT EXISTS `raja_store` (
  `str_id` int(11) NOT NULL AUTO_INCREMENT,
  `str_code` varchar(9) COLLATE utf32_bin NOT NULL,
  `str_name` varchar(30) COLLATE utf32_bin NOT NULL,
  `str_detail` text COLLATE utf32_bin NOT NULL,
  PRIMARY KEY (`str_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf32 COLLATE=utf32_bin AUTO_INCREMENT=2 ;

--
-- Dumping data for table `raja_store`
--

INSERT INTO `raja_store` (`str_id`, `str_code`, `str_name`, `str_detail`) VALUES
(1, 'A', 'Gudang 1a', 0x7b);

-- --------------------------------------------------------

--
-- Table structure for table `raja_suplier`
--

CREATE TABLE IF NOT EXISTS `raja_suplier` (
  `sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_code` varchar(20) DEFAULT NULL,
  `sup_name` varchar(30) NOT NULL,
  `sup_detail` text NOT NULL,
  `sup_stat` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sup_id`),
  UNIQUE KEY `sup_code` (`sup_code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `raja_suplier`
--

INSERT INTO `raja_suplier` (`sup_id`, `sup_code`, `sup_name`, `sup_detail`, `sup_stat`) VALUES
(1, 'TWT', 'testing 32', '{"address":"bla-bla bla","phone":"124125125125"}', 1),
(2, 'TWT2', 'TEST34', '{"address":"adasdsa","phone":"123124"}', 0),
(4, 'TWT2f', 'asdsa', '', 1),
(5, 'Tui', 'dasdas', '', 1),
(6, '123', 'dsada', '{"address":"dsadas","phone":"sadasdas"}', 0),
(7, '13213', '231', '', 0),
(8, '31231', '4124412', '', 0),
(9, '123i', '1241', '', 0),
(10, '123b', '213123', '', 0),
(11, '123c', '', '', 0),
(12, '123d', '123123123', '', 0),
(13, '123r', '2315', '', 0),
(14, '123123d', 'r21', '', 0),
(15, '421251', 'asafas', '', 0),
(16, '41dwq', 'dqd', '', 0),
(17, 'eq3', 'wq', '', 1),
(18, 'scar', 'eqe', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `raja_tab`
--

CREATE TABLE IF NOT EXISTS `raja_tab` (
  `tab_id` int(11) NOT NULL AUTO_INCREMENT,
  `tab_name` varchar(20) NOT NULL,
  `tab_detail` text NOT NULL,
  PRIMARY KEY (`tab_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `raja_tab`
--

INSERT INTO `raja_tab` (`tab_id`, `tab_name`, `tab_detail`) VALUES
(1, 'welcome', 'hello world');

-- --------------------------------------------------------

--
-- Table structure for table `raja_user`
--

CREATE TABLE IF NOT EXISTS `raja_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `user_realname` varchar(40) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `raja_user`
--

INSERT INTO `raja_user` (`user_id`, `user_name`, `user_realname`, `user_password`) VALUES
(1, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'gundam', 'gundam', '9163f2b67e738edf854cbfda80aef9af');

-- --------------------------------------------------------

--
-- Table structure for table `raja_usermenu`
--

CREATE TABLE IF NOT EXISTS `raja_usermenu` (
  `user` int(11) NOT NULL,
  `menu` text NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `raja_usertab`
--

CREATE TABLE IF NOT EXISTS `raja_usertab` (
  `utab_user` int(11) NOT NULL AUTO_INCREMENT,
  `utab_tab` text NOT NULL,
  PRIMARY KEY (`utab_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
