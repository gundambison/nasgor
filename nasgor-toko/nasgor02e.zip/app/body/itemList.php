<?php
loadMod('category');
loadMod('store_mods');
loadMod('product_mods');
loadMod('merk_mods');

if(!checkLogin())
{
	redirect(my_url()."login");

}

$data=array(
'title'=>'Produk',
'content'=>'item/table_view',
'tab'=>array(),
'nav'=>array(),
'breadcrumb'=>'Produk (item)'
);

showView('index1_view', $data); 