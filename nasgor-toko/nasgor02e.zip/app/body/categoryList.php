<?php
if(!checkLogin())
{
	redirect(my_url()."login");

}

$data=array(
'title'=>'Kategori',
'content'=>'category/table_view',
'tab'=>array(),
'nav'=>array(),
'breadcrumb'=>'Kategori (category)'
);

showView('index1_view', $data); 