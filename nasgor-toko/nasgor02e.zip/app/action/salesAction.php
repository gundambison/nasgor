<?php
ob_start();
 
$act= myUri(2);

if($act=='new')
{
foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	
	$phone=addslashes(json_encode($_POST['phone']));
	$det='';
	 
	$id=auto_id();
	 
	$ar=array(sales_id=>$id, 'sales_code'=>$sales_code , 'sales_customer'=>$sales_customer , 'sales_date'=>$sales_date , 'sales_shipp'=>$sales_shipp , 'sales_cost'=>$sales_cost , 'sales_total'=>$sales_total , 'sales_weight'=>$sales_weight , 'sales_stat'=>$sales_stat , 'sales_payto'=>$sales_payto , 'sales_sendby'=>$sales_sendby , 'sales_type'=>$sales_type ); 
	dbInsert("{$prefix}sales",$ar);	 
	
}

if($act=='update')
{
	foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	//$err='not yet'; 
	
	$phone=addslashes(json_encode($phone1));
	$sql="UPDATE   `{$prefix}sales` SET  
 sales_code ='".addslashes($sales_code).",
 sales_customer ='".addslashes($sales_customer).",
 sales_date ='".addslashes($sales_date).",
 sales_shipp ='".addslashes($sales_shipp).",
 sales_cost ='".addslashes($sales_cost).",
 sales_total ='".addslashes($sales_total).",
 sales_weight ='".addslashes($sales_weight).",
 sales_stat ='".addslashes($sales_stat).",
 sales_payto ='".addslashes($sales_payto).",
 sales_sendby ='".addslashes($sales_sendby).",
 sales_type ='".addslashes($sales_type)."
WHERE   `sales_id` =$sales_id;";
	 query($sql); 
	
}

//==================OTHER ADD HERE===========

$post=ob_get_contents();	
ob_end_clean(); 
$a=array($post);
if(@isset($err)) $a['err']=$err;
echo json_encode($a);