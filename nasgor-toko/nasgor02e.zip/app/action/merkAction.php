<?php
ob_start();
 
$act= myUri(2);

if($act=='new')
{
foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	
	//$phone=addslashes(json_encode($_POST['phone']));
	$det='';
	 
	$id=auto_id();
	 
	$ar=array('merk_id'	=>$id, 'merk_code'=>$merk_code , 'merk_name'=>$merk_name , 'merk_stat'=>$merk_stat  ); 
	dbInsert("{$prefix}merk",$ar);	 
	$det=json_encode($_POST['det']);
	$ar=array('merkdet_id'=>$id, 'merkdet_detail'=>$det);
	dbInsert("{$prefix}merkdetail",$ar);	
	
}

if($act=='update')
{
	foreach($_POST as $n=>$v){
		$$n=@addslashes( $v );
 
	}
	//$err='not yet'; 
 
	$sql="UPDATE   `{$prefix}merk` SET   
 merk_name ='".addslashes($merk_name)."',
 merk_stat ='".addslashes($merk_stat)."' 
WHERE   `merk_id` =$merk_id;";
	 query($sql); 
	 $det=json_encode($_POST['det']);
	 $sql="update {$prefix}merkdetail set
	 merkdet_detail='".addslashes($det)."'
	 where merkdet_id=$merk_id";
	 
	query($sql); 
}

//==================OTHER ADD HERE===========

$post=ob_get_contents();	
ob_end_clean(); 
$a=array($post);
if(@isset($err)) $a['err']=$err;
echo json_encode($a);