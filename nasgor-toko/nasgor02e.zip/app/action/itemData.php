<?php
ob_start();
loadMod('category');
loadMod('store_mods');
loadMod('product_mods');
loadMod('merk_mods');
foreach($_POST as $n=>$v)$$n=$v;
 
//$type & $key

$a=array();
if(!isset($type))
{
	$sql="select count(item_id) c from `{$prefix}item` order by item_id desc";
}else{
/*just example */
  if($type=='code')
  {
	$sql="select count(item_id) c from `{$prefix}item` where item_code like '$key%'
	order by item_id desc";
  }
  
  
}

//echo $sql;

$q=$mysqli->query($sql);
	if(!$q)
	{
		die($mysqli->error);
	}
	$i=1;
	$data=array();
$r=$row = $q->fetch_assoc();//num_rows($q)
$result["total"]=$r['c'];	

$n=($page-1)*$rows;
if(!isset($type))
{
	$sql="select * from `{$prefix}item`  
	group by item_id
	order by item_id desc
	limit $n,$rows";
}else{
/*just example */
  if($type=='code')
  {
	$sql="select * from `{$prefix}item` 
	 where item_code like '$key%' 	 
	 group by item_id
	order by item_id desc";
  }
   
}	
	echo $sql;

$q=query($sql);
	while ($row = $q->fetch_assoc()) 
	{
	  if($row['item_stat']==0){
		$stat='Hide';
	  }else{
		$stat='Show';
	  }
//==========category
		$ar=catDetail($row['item_cat']);
		//print_r($ar);print_r($row);die();
		$cat=$ar['cat_name'];
		
//==========Merk
		$ar=merkDetail($row['item_merk']);
		$merk=$ar['merk_name'];
	  
		 $data=array(
		 'id'=>$row['item_id'],
	'code'=>$row['item_code'],
	'name'=>$row['item_name'],
	'stat'=>$stat,
	'price'=>$row['item_price'],
	'disc'=>$row[item_disc],
	'stock'=>$row[item_stock],
	'cat'=>$cat,
	'merk'=>$merk
		  
		 );
		 
		 //==========LINK
		 $data['link']='next';
		 $a[]=$data;
		 
	}
print_r($_POST);

 $post=ob_get_contents();	
 ob_end_clean();    
 
//$a[]=$post;   
$result["rows"]=$a; 
//$result[]=$post; 
echo json_encode($result);
 