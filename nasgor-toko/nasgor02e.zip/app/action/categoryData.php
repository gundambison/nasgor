<?php
ob_start();
 
foreach($_POST as $n=>$v)$$n=$v;
 
//$type & $key

$a=array();
if(!isset($type))
{
	$sql="select count(cat_id) c from `{$prefix}category` order by cat_id desc";
}else{
 
  if($type=='code')
  {
	$sql="select count(cat_id) c from `{$prefix}category` where cat_code like '$key%'
	order by cat_id desc";
  }
  if($type=='name')
  {
	$sql="select count(cat_id) c from `{$prefix}category` where cat_name like '$key%'
	order by cat_id desc";
  }
  if($type=='parent')
  {
	$sql="select count(c1.cat_id) c from `{$prefix}category` c1, `{$prefix}category` c2
	where (c1.cat_parent like '$key%' or
	c2.cat_code like '$key%') and
	c1.cat_parent =c2.cat_id
	order by c1.cat_id desc";
  }
  
}

//echo $sql;

$q=$mysqli->query($sql);
	if(!$q)
	{
		die($mysqli->error);
	}
	$i=1;
	$data=array();
$r=$row = $q->fetch_assoc();//num_rows($q)
$result["total"]=$r['c'];	

$n=($page-1)*$rows;
if(!isset($type))
{
	$sql="select * from `{$prefix}category`  
	group by cat_id
	order by cat_id desc
	limit $n,$rows";
}else{
/*just example */
  if($type=='code')
  {
	$sql="select * from `{$prefix}category` 
	 where cat_code like '$key%' 	 
	 group by cat_id
	order by cat_id desc";
  }
  
  if($type=='name')
  {
	$sql="select * from `{$prefix}category` where cat_name like '$key%'
	order by cat_id desc";
  }
  
  if($type=='parent')
  {
	$sql="select c1.* from `{$prefix}category` c1, `{$prefix}category` c2
	where (c1.cat_parent like '$key%' or
	c2.cat_code like '$key%') and
	c1.cat_parent =c2.cat_id
	order by c1.cat_id desc";
  }
  
   
}	
	//echo $sql;

$q=query($sql);
	while ($row = $q->fetch_assoc()) 
	{
		$stat=$row['cat_stat']==1?'Aktif':'Hide';
		if($row['cat_parent']!=0)
		{
			$sql="select cat_name name from `{$prefix}category`  
			where cat_id='{$row['cat_parent']}'";
			$q2=query($sql);
			$row2 = $q2->fetch_assoc();
			$parent=$row2['name'];
		}else{
			$parent="Top";
		}
		 $data=array(
		 'id'=>$row['cat_id'],
	'code'=>$row['cat_code'],
	'name'=>$row['cat_name'],
	'stat'=>$stat,
	'parent'=>$parent
		  
		 );
		 
		 //==========LINK
		 $data['link']='next';
		 $a[]=$data;
		 
	}
print_r($_POST);

 $post=ob_get_contents();	
 ob_end_clean();    
 
//$a[]=$post;   
$result["rows"]=$a; 
$result[]=$post; 
echo json_encode($result);
 