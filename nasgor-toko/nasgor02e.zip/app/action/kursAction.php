<?php
ob_start();
 
$act= myUri(2);

if($act=='new')
{
foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	
	$phone=addslashes(json_encode($_POST['phone']));
	$det='';
	 
	$id=auto_id();
	 $k_date=date("Y-m-d");
	$ar=array('k_id'=>$id, 'k_code'=>$k_code , 'k_name'=>$k_name ,   'k_price'=>$k_price , 'k_date'=>$k_date , 'k_source'=>$k_source ); 
	dbInsert("{$prefix}kurs",$ar);	

	$ar=array('kdet_id'=>$id,'kdet_detail'=>json_encode($_POST['det']));
	dbInsert("{$prefix}kursdetail",$ar);	
	
}

if($act=='updatePrice')
{
	foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	$sql="select k_price price,k_date date from `{$prefix}kurs` where `k_id` =$k_id;";
	$q=query($sql); $row=fetch($q);
 
	$id=auto_id();
	$ar=array('log_id'=>$id,'log_kurs'=>$k_id,'log_price'=>$row['price'],
	'log_date'=>$row['date'],'log_user'=>sess_value("{$prefix}userid"));
	 
	dbInsert("{$prefix}kurslog",$ar);
 
	$date=date("Y-m-d");
	$sql="UPDATE   `{$prefix}kurs` SET   
 k_price ='".addslashes($price)."',
 k_date ='".addslashes($date)."'
WHERE   `k_id` =$k_id;";
	//print_r($_POST);die($sql);
	query($sql); 

}

if($act=='update')
{
	foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	$sql="select k_price from `{$prefix}kurs` where `k_id` =$k_id;";
	$q=query($sql); $row=fetch($q);
	/*
	$id=auto_id();
	$ar=array('log_id'=>$id,'log_kurs'=>$k_id,'log_price'=>$row['price'],
	'log_date'=>$row['date'],'log_user'=>sess_value("{$prefix}userid"));
	dbInsert("{$prefix}kurslog",$ar);
	*/
	$kdet_detail=addslashes(json_encode($_POST['det']));

	$sql="UPDATE   `{$prefix}kurs` SET   
 k_name ='".addslashes($k_name)."',
 k_stat ='".addslashes($k_stat)."',
 
 k_source ='".addslashes($k_source)."'
WHERE   `k_id` =$k_id;";
	query($sql); 
	$sql="delete from {$prefix}kursdetail where kdet_id='$k_id'";
	query($sql);
	
	$ar=array('kdet_id'=>$k_id,'kdet_detail'=>json_encode($_POST['det']));
	dbInsert("{$prefix}kursdetail",$ar);
}

//==================OTHER ADD HERE===========

$post=ob_get_contents();	
ob_end_clean(); 
$a=array($post);
if(@isset($err)) $a['err']=$err;
echo json_encode($a);