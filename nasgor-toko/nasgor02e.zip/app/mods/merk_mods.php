<?php
function merkList()
{
global $prefix;
	$sql="select * from `{$prefix}merk`  
	order by merk_name asc"; 
	$q=query($sql);
	return $q;
}

function merkDetail($id)
{
	global $prefix;
	$sql="select * from `{$prefix}merk` where merk_id=$id  "; 
	$q=query($sql);
	$data=fetch($q);
	$sql="select merkdet_detail detail 
	from `{$prefix}merkdetail` 
	where merkdet_id=$id"; 
	$q=query($sql);
	$data2=fetch($q); //echo "<hr>$sql";print_r($data2);
	$data3=json_decode($data2['detail'], TRUE);
	$data=@array_merge($data, $data3);
	return $data;

}