<?php

function catList($parent)
{
global $prefix;
	$sql="select * from `{$prefix}category` where cat_parent=$parent 
	order by cat_id desc"; 
	$q=query($sql);
	return $q;
}

function catDetail($id)
{
global $prefix;
	$sql="select * from `{$prefix}category` where cat_id=$id 
	order by cat_id desc"; 
	$q=query($sql);
	$data=fetch($q);//print_r($data);
	 
	return $data;
}

function catSelectSubList($parent, $num, $sel=0, $id=1)
{
global $prefix;
	$sql="select count(cat_id) c from `{$prefix}category` where cat_parent=$parent"; 
	$q=query($sql);$r=$q->fetch_assoc();
	if($r['c']==0)
	{
		return "";
	}else{
		 $q=catList($parent);
		$strip='';
		for($i=0;$i<$num;$i++)$strip.="-";
		$num++;
		while ($row  = $q ->fetch_assoc()) 
		{
			$sel=$sel==$row['cat_id']?'selected':'';
			if($id!=$row['cat_id'])	
				echo "<option $sel value='{$row['cat_id']}'>{$strip} {$row['cat_name']}</option>\n";
		?><optgroup label="<?=$strip.$row['cat_name'];?>">
	<? echo catSelectSubList($row['cat_id'],$num);?>
	</optgroup><?php
			
		}
	}

}