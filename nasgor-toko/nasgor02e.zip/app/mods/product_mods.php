<?php

function productList($parent)
{
global $prefix;
	$sql="select * from `{$prefix}category` where cat_parent=$parent 
	order by cat_id desc"; 
	$q=query($sql);
	return $q;
}