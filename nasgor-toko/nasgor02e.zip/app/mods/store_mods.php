<?php

function storeList()
{
global $prefix;
	$sql="select * from `{$prefix}store`  
	order by str_name asc"; 
	$q=query($sql);
	return $q;
}