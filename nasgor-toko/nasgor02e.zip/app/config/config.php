<?php 
$siteUrl="http://localhost:8001/nasgor-toko/";	
$baseBody="home";
 