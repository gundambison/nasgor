<form id='UpdateForm' style='margin:12px 20px'><?php
$id=myUri(3);
/*
Please edit the query
*/
$sql="select c1.* from `".prefix()."category` c1 

 where cat_id='$id' ";
/*
,c2.catdet_detail detail
 and
 catdet_id = cat_id
 */
$q=query($sql);
$data=fetch($q);?><!-- <?php print_r($data);?>--><?php
foreach($data as $n=>$v)
{
	$nm=str_replace("cat_","",$n  );
	$$nm=$v;
	 
}
 
$sql="select c2.catdet_detail detail
from `".prefix()."categorydetail` c2
where catdet_id =$id";
$q1=query($sql);
$data=fetch($q1);$detail=$data['detail'];

$det=json_decode($detail, true); ?><input type='hidden' name='cat_id' value='<?=$id;?>' />
	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='cat_code' value='<?=$code;?>' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='cat_name' value='<?=$name;?>' />
	<label type='txt'>STATUS</label>
	  <input type=radio  name='cat_stat' value='1' <? 
	  if($stat==1) echo 'checked'; ?>  /> Aktif
	  <input type=radio  name='cat_stat' value='0' <? 
	  if($stat==0) echo 'checked'; ?>  /> Hide
	<label type='num'>PARENT</label>
	  <select name='cat_parent'>
	  <option value='0' <?php if($parent==0) echo 'selected' ?>>TOP</option>
<?php
$q1=catList(0);
while ($row = $q1->fetch_assoc()) 
{
	$sel=$parent==$row['cat_id']?'selected':'';
	if($id!=$row['cat_id'])	
		echo "<option $sel value='{$row['cat_id']}'>{$row['cat_name']}</option> ";
	$q2=catList($row['cat_id']);
	while ($row2 = $q2->fetch_assoc()) 
	{
		$sel=$parent==$row2['cat_id']?'selected':'';
		if($id!=$row2['cat_id'])	
			echo "<option x $parent $sel value='{$row2['cat_id']}' >-{$row2['cat_name']}</option>\n";
		echo catSelectSubList($row2['cat_id'],2,$parent,$id);
	}
	
}
?>	  
	  </select>
	 
	<h3>DETAIL</h3>	<label type='text'>DESC</label>
	  <textarea placeholder='Detail' name='cat_detail' style='width:300px;height:100px'><?=$detail;?></textarea>	 
	<p><input type=button onclick='updateForm()' value='update' />
</form>