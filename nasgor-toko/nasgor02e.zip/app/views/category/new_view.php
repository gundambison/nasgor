<form id='UpdateForm' style='margin:12px 20px'><?php  
?>	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='cat_code' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='cat_name' />
	<label type='txt'>STATUS</label>
	  <input type=text placeholder='Status' name='cat_stat' />
	<label type='num'>PARENT</label>
	  <select name='cat_parent'>
	  <option value='0'>TOP</option>
<?php
$q=catList(0);
while ($row = $q->fetch_assoc()) 
{
	echo "<option value='{$row['cat_id']}'>{$row['cat_name']}</option>\n";
	$q2=catList($row['cat_id']);
	while ($row2 = $q2->fetch_assoc()) 
	{
		echo "<option value='{$row2['cat_id']}'>-{$row2['cat_name']}</option>\n";
		echo catSelectSubList($row2['cat_id'],2);
	}
	
}
?>	  
	  </select>
	<label type='txt'>DETAIL</label>
	  <textarea placeholder='Detail' name='cat_detail' style='width:300px;height:100px'></textarea>
	 
	<p><input type=button onclick='newData()' value='save' />
</form>
