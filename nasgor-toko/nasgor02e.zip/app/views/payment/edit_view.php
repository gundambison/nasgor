<form id='UpdateForm' style='margin:12px 20px'><?php
$id=myUri(3);
/*
Please edit the query
*/
$sql="select * from `".prefix()."payment`,
`".prefix()."paymentdetail`
 where payment_id='$id' and
 paymentdet_id = payment_id";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
	$nm=str_replace("payment_","",$n  );
	$$nm=$v;
	 
}
 

$det=json_decode($detail, true); ?><!-- <?php print_r($data);?>--><input type='hidden' name='payment_id' value='<?=$id;?>' />
	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='payment_code' value='<?=$code;?>' />
	<label type='num'>SALES</label>
	  <input type=text placeholder='Sales' name='payment_sales' value='<?=$sales;?>' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='payment_nama' value='<?=$nama;?>' />
	<label type='num'>VIA</label>
	  <input type=text placeholder='Via' name='payment_payto' value='<?=$payto;?>' />
	<label type='num'>SEJUMLAH</label>
	  <input type=text placeholder='Sejumlah' name='payment_value' value='<?=$value;?>' />
	<label type='txt'>DIBUAT</label>
	  <input type=text placeholder='Dibuat' name='payment_create' value='<?=$create;?>' />
	<label type='num'>STATUS</label>
	  <input type=text placeholder='Status' name='payment_stat' value='<?=$stat;?>' />
	<h3>DETAIL</h3>	<label type='text'>DESC</label>
	  <input type=text placeholder='desc' name='det[Keterangan]' value='<?=$det[Keterangan];?>' />	 
	<p><input type=button onclick='updateForm()' value='update' />
</form>