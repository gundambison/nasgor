<form id='UpdateForm' style='margin:12px 20px'><?php /* JUST EXAMPLE.. delete if you don't use this -->	
	<label>Code</label>
	<input type=text placeholder='Code' name='payment_code' value='<?php
$code=date("ymd");
$code.=sprintf("%04s",
	strtoupper(dechex(auto_id()%4000))
); 	
	echo $code;
	?>' readonly />
	 *jangan terlalu panjang*/ 
?>	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='payment_code' />
	<label type='num'>SALES</label>
	  <input type=text placeholder='Sales' name='payment_sales' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='payment_nama' />
	<label type='num'>VIA</label>
	  <input type=text placeholder='Via' name='payment_payto' />
	<label type='num'>SEJUMLAH</label>
	  <input type=text placeholder='Sejumlah' name='payment_value' />
	<label type='txt'>DIBUAT</label>
	  <input type=text placeholder='Dibuat' name='payment_create' />
	<label type='num'>STATUS</label>
	  <input type=text placeholder='Status' name='payment_stat' />
	<h3>DETAIL</h3>	<label type='text'>DESC</label>
	  <input type=text placeholder='desc' name='det[Keterangan]'  />
	<p><input type=button onclick='newData()' value='save' />
</form>
