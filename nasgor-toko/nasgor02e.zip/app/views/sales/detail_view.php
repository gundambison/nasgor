<?php
$id=myUri(3);
$sql="select * from `".prefix()."sales` where sales_id='$id'";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
   $nm=str_replace("sales_","",$n  );
   $$nm=$v;
    
}

 
?>	<label>KODE</label>
	    <?=$code;?>
	<label>PELANGGAN</label>
	    <?=$customer;?>
	<label>TANGGAL</label>
	    <?=$date;?>
	<label>PEMBELIAN</label>
	    <?=$shipp;?><!--
	try fix this detail
-->
	<label>NAMA DITUJU</label>
	    <?=$Keterangan;?>
	<label>ALAMAT</label>
	    <?=$Address;?>
	<label>KOTA</label>
	    <?=$City;?>
	<label>KODEPOS</label>
	    <?=$CityCode;?>
	<label>DIKIRIM</label>
	    <?=$SendBy;?>
	<label>HARGA PERKILO</label>
	    <?=$Pricekg;?>
	<label>POTONGAN</label>
	    <?=$Discount;?>
	<label>PESAN</label>
	    <?=$Message;?>
	<label>KETERANGAN</label>
	    <?=$adminnote;?>