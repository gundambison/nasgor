<div class="container body1"> 
	 
	<div style="margin:10px 0;"></div>
	<div id="tt" class="easyui-tabs" style="width:900px;height:550px;">
		<div title="Home" style="padding:20px">
			SELAMAT DATANG ... SILAKAN PILIH DARI MENU YANG TERSEDIA. Penjelasan Menu
			<ol>
			<li>Supplier. Nama-nama Suplier yang dibeli
			<li>Toko/Gudang. Gudang tempat penyimpanan barang. 
			<li>Pelanggan. Pelanggan yang terdata
			<li>Kurs
			
			</ol>
			
		</div>
	</div>
</div> 
 
