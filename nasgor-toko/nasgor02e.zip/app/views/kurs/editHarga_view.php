 
<form id='UpdateForm' style='margin:12px 20px'><?php
$id=myUri(3);
/*
Please edit the query
*/
$sql="select k.*  from 
`".prefix()."kurs` k 
 where k_id='$id'  ";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
	$nm=str_replace("k_","",$n  );
	$$nm=$v;
	 
}
?>
  Tanggal
	<input type='k_date' value='<?=$date;?>' readonly size=10 />
	*tanggal terakhir update. 
	Otomatis di update sesuai tanggal berjalan*
	  
  Harga
	<input type='k_price' name='price' value='<?=$price;?>' />
	<input type='hidden' name='k_id' value='<?=$id;?>' />
<p><input type=button onclick='updatePriceForm()' value='update' />
</form>
<script>
 
function datePick()
{
    $( "#datepicker" ).datepicker();
	console.log('error');
}
</script>