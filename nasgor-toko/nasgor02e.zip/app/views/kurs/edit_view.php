<form id='UpdateForm' style='margin:12px 20px'><?php
$id=myUri(3);
/*
Please edit the query
*/
$sql="select k.*, det.kdet_detail detail from 
`".prefix()."kurs` k,
`".prefix()."kursdetail` det
 where k_id='$id' and
 kdet_id = k_id";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
	$nm=str_replace("k_","",$n  );
	$$nm=$v;
	 
}
 


$det=json_decode($data['detail'], true); ?><!-- <?php print_r($det);?>--><input type='hidden' name='k_id' value='<?=$id;?>' />
	<label type='txt'>KODE</label>
	  <input type=text readonly placeholder='Kode' name='k_code' value='<?=$code;?>' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='k_name' value='<?=$name;?>' />
	<label type='txt'>STATUS</label>
	  <input type=radio placeholder='Status' name='k_stat' value=1 <?
if($stat==1) echo 'checked';
	  ?>
	  >Aktif	  <input type=radio placeholder='Status' name='k_stat' 
	  <?
if($stat==0) echo 'checked';
	  ?>
	  value=0  >Hide
	 <label type='txt'>SUMBER</label>
	  <input type=text placeholder='sumber' name='k_source' value='<?=$source;?>' />
	<h3>DETAIL</h3>	<label type='chr'>DARI</label>
	  <input type=text placeholder='dari' name='det[from]' 
	  value='<?=$det['from'];?>' />
	<label type='text'>DETAIL</label>
	  <textarea style='width:400px;height:100px' name='det[more]' ><?=$det['more'];?></textarea>	 
	<p><input type=button onclick='updateForm()' value='update' />
</form>