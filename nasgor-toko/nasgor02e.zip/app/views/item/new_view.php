<style>
.alamat{
margin:0; padding:0;
}
</style><form id='UpdateForm' style='margin:12px 20px'> <Input 
type='hidden' name='item_id' value='<?=auto_id('item');?>' />
	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='item_code' />
	<label type='char'>BARCODE</label>
	  <input type=text placeholder='Barcode' name='det[barcode]'  />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='item_name' />
	<label type='txt'>STATUS</label>
	  <input type=radio  name='item_stat' value=1 checked />Aktif <input type=radio  name='item_stat' value=0  />Tidak Aktif 
	  
	<label type='num'>HARGA</label>
	  <input type=text placeholder='Harga' name='item_price' sixe=7  />
	<label type='num'>DISKON</label>
	  <input type=text placeholder='Diskon' name='item_disc' size=3 value=0 />
	<label type='txt'>UKURAN</label>
	  <input type=text placeholder='Ukuran' name='item_size' />s,m,l,ll
	<label type='num'>STOCK</label>
	  <input type=text placeholder='Stock' name='item_stock' size=4 value=0 />
	<label type='txt'>HARGA BELI</label>
	  Rp<input type=text placeholder='Harga Beli' name='item_price0' size=7 />
	<label type='num'>MINIMAL</label>
	  <input type=text placeholder='Minimal' name='item_stock0' size=2 value=0 />
	<label type='txt'>GUDANG</label>
	  <select name='item_store'  >
<?php
$store=storeList();
while($data=fetch($store))
{
	?><option value='<?=$data['str_id'];?>'><?=$data['str_name'];?></option>
	<?php
}
?>	  
	  </select>
	<label type='num'>CATEGORY</label>
	  <select name='item_cat'><?php
$cat=catList(0);
while($data=fetch($cat))
{
	?><option value='<?=$data['cat_id'];?>'><?php 
	echo $data['cat_name']; ?></option>
	 
	<? catSelectSubList($data['cat_id'],1  ) ?>
	<?php
}
?></select>
	<label type='txt'>MERK</label>
	  <select name='item_merk'><?php
$cat=merkList(0);
while($data=fetch($cat))
{
	if($data['merk_stat']==1){
	?><option value='<?=$data['merk_id'];?>'><?php 
	echo $data['merk_name']; ?></option><?php
	}
}
?>
	  </select>
	<label type='num'>HOT</label>
	  <input type=radio  name='det[hot]' value=1 />Aktif <input type=radio  name='det[hot]' value=0 checked />Tidak Aktif
	<h3>DETAIL</h3>	<label type='chr'>EXPIRE</label>
	  <input type=text placeholder='tahun-bulan-tanggal' name='det[expire]'   />
	<label type='chr'>WARNA</label>
	  <input type=text placeholder='warna' name='det[color]'  size=8 />
	<label type='char'>SATUAN</label>
	  <input type=text placeholder='Satuan' name='det[pcs]' value='pcs' size=6 />
	<label type='text'>DETAIL</label>
	  <textarea name='det[desc]'  
	  style='width:400px;height:100px;'></textarea>	
	<label type='char'>RAK</label>
	  <input type=text placeholder='Rak' name='det[rak]'  />
	<p><input type=button onclick='newData()' value='save' />
</form>
