<?php
$id=myUri(3);
$sql="select * from `".prefix()."merk` where merk_id='$id'";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
   $nm=str_replace("merk_","",$n  );
   $$nm=$v;
    
}

$sql="select merkdet_detail detail from `".prefix()."merkdetail` 
where merkdet_id='$id'";
$q=query($sql);
$data=fetch($q); $det=json_decode($data['detail'],TRUE);

 
?>	<label>KODE</label>
	    <?=$code;?>
		
	<label>NAMA</label>
	    <?=$name;?>
	 
	<label>KETERANGAN</label>
	    <?=$det['desc'];?>
		
	<label>ALAMAT</label>
	    <?=$det['address'];?>
		
	<label>CP</label>
	    <?=$det['contact'];?>