<form id='UpdateForm' style='margin:12px 20px'><?php
$id=myUri(3);
/*
Please edit the query
*/
$sql="select m.*, merkdet_detail detail 
from `".prefix()."merk` m ,  `".prefix()."merkdetail` md
 where merk_id='$id'  ";
 
$q=query($sql);//echo $sql;
$data=fetch($q);//print_r($data);
foreach($data as $n=>$v)
{
	$nm=str_replace("merk_","",$n  );
	$$nm=$v;
	 
}
 

$det=json_decode($detail, true); ?><!-- <?php print_r($det);?>--><input type='hidden' name='merk_id' value='<?=$id;?>' />
	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' readonly value='<?=$code;?>' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='merk_name' value='<?=$name;?>' />
	<label type='txt'>STATUS</label>
	  <input type=radio  name='merk_stat' value='1' <? 
	  if($stat==1) echo 'checked'; ?>  /> Aktif
	  <input type=radio  name='merk_stat' value='0' <? 
	  if($stat==0) echo 'checked'; ?>  /> Hide
	<h3>DETAIL</h3>	<label type='text'>KETERANGAN</label>
	  <input type=text placeholder='keterangan' name='det[desc]' 
	  value='<?=$det['desc'];?>' />
	<label type='text'>ALAMAT</label>
	  <textarea placeholder='alamat' name='det[address]' style='width:300px;height:100px;'  ><?=$det['address'];?></textarea>
	<label type='char'>CP</label>
	  <input type=text placeholder='CP' name='det[contact]' value='<?=$det['contact'];?>' />	 
	<p><input type=button onclick='updateForm()' value='update' />
</form>