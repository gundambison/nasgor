<form id='UpdateForm' style='margin:12px 20px'><?php /* JUST EXAMPLE.. delete if you don't use this -->	
	<label>Code</label>
	<input type=text placeholder='Code' name='merk_code' value='<?php
$code=date("ymd");
$code.=sprintf("%04s",
	strtoupper(dechex(auto_id()%4000))
); 	
	echo $code;
	?>' readonly />
	 *jangan terlalu panjang*/ 
?>	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='merk_code' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='merk_name' />
	<label type='txt'>STATUS</label>
	  <input type=radio  name='merk_stat' value=1 checked />Aktif <input type=radio  name='merk_stat' value=0  />Tidak Aktif
 
	<h3>DETAIL</h3>	<label type='text'>KETERANGAN</label>
	  <input type=text placeholder='keterangan' name='det[desc]' style='width:300px'  />
	<label type='text'>ALAMAT</label>
	  <textarea placeholder='alamat' name='det[address]' style='width:300px;height:100px;'  ></textarea>
	<label type='char'>CP</label>
	  <input type=text placeholder='CP' name='det[contact]'  />
	<p><input type=button onclick='newData()' value='save' />
</form>
