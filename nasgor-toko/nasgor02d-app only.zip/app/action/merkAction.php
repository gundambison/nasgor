<?php
ob_start();
 
$act= myUri(2);

if($act=='new')
{
foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	
	$phone=addslashes(json_encode($_POST['phone']));
	$det='';
	 
	$id=auto_id();
	 
	$ar=array(merk_id=>$id, 'merk_code'=>$merk_code , 'merk_name'=>$merk_name , 'merk_stat'=>$merk_stat , 'merk_'=>$merk_ ); 
	dbInsert("{$prefix}merk",$ar);	 
	
}

if($act=='update')
{
	foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	//$err='not yet'; 
	
	$phone=addslashes(json_encode($phone1));
	$sql="UPDATE   `{$prefix}merk` SET  
 merk_code ='".addslashes($merk_code).",
 merk_name ='".addslashes($merk_name).",
 merk_stat ='".addslashes($merk_stat).",
 merk_ ='".addslashes($merk_)."
WHERE   `merk_id` =$merk_id;";
	 query($sql); 
	
}

//==================OTHER ADD HERE===========

$post=ob_get_contents();	
ob_end_clean(); 
$a=array($post);
if(@isset($err)) $a['err']=$err;
echo json_encode($a);