<?php
ob_start();
 
$act= myUri(2);

if($act=='new')
{
foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	
	$phone=addslashes(json_encode($_POST['phone']));
	$det='';
	 
	$id=auto_id();
	 
	$ar=array(payment_id=>$id, 'payment_code'=>$payment_code , 'payment_sales'=>$payment_sales , 'payment_nama'=>$payment_nama , 'payment_payto'=>$payment_payto , 'payment_value'=>$payment_value , 'payment_create'=>$payment_create , 'payment_stat'=>$payment_stat ); 
	dbInsert("{$prefix}payment",$ar);	 
	
}

if($act=='update')
{
	foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	//$err='not yet'; 
	
	$phone=addslashes(json_encode($phone1));
	$sql="UPDATE   `{$prefix}payment` SET  
 payment_code ='".addslashes($payment_code).",
 payment_sales ='".addslashes($payment_sales).",
 payment_nama ='".addslashes($payment_nama).",
 payment_payto ='".addslashes($payment_payto).",
 payment_value ='".addslashes($payment_value).",
 payment_create ='".addslashes($payment_create).",
 payment_stat ='".addslashes($payment_stat)."
WHERE   `payment_id` =$payment_id;";
	 query($sql); 
	
}

//==================OTHER ADD HERE===========

$post=ob_get_contents();	
ob_end_clean(); 
$a=array($post);
if(@isset($err)) $a['err']=$err;
echo json_encode($a);