<?php
ob_start();
 
$act= myUri(2);

if($act=='new')
{
foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	
	$phone=addslashes(json_encode($_POST['phone']));
	$det='';
	 
	$id=auto_id();
	 
	$ar=array(cat_id=>$id, 'cat_code'=>$cat_code , 'cat_name'=>$cat_name , 'cat_stat'=>$cat_stat , 'cat_parent'=>$cat_parent , 'cat_detail'=>$cat_detail ); 
	dbInsert("{$prefix}category",$ar);	 
	
}

if($act=='update')
{
	foreach($_POST as $n=>$v)$$n=@addslashes( $v );
	//$err='not yet'; 
	
	$phone=addslashes(json_encode($phone1));
	$sql="UPDATE   `{$prefix}category` SET  
 cat_code ='".addslashes($cat_code).",
 cat_name ='".addslashes($cat_name).",
 cat_stat ='".addslashes($cat_stat).",
 cat_parent ='".addslashes($cat_parent).",
 cat_detail ='".addslashes($cat_detail)."
WHERE   `cat_id` =$cat_id;";
	 query($sql); 
	
}

//==================OTHER ADD HERE===========

$post=ob_get_contents();	
ob_end_clean(); 
$a=array($post);
if(@isset($err)) $a['err']=$err;
echo json_encode($a);