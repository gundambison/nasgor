<?php
if(!checkLogin())
{
	redirect(my_url()."login");

}

$data=array(
'title'=>'Pembayaran Penjualan',
'content'=>'payment/table_view',
'tab'=>array(),
'nav'=>array(),
'breadcrumb'=>'Pembayaran Penjualan (payment)'
);

showView('index1_view', $data); 