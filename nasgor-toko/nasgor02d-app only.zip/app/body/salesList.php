<?php
if(!checkLogin())
{
	redirect(my_url()."login");

}

$data=array(
'title'=>'Penjualan',
'content'=>'sales/table_view',
'tab'=>array(),
'nav'=>array(),
'breadcrumb'=>'Penjualan (sales)'
);

showView('index1_view', $data); 