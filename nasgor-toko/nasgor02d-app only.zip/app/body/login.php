<?php
$data=array(
'title'=>'Login',
'content'=>'login_view',
'tab'=>array(),
'nav'=>array(),
'breadcrumb'=>'Login'
);
 
 
showView('index1_view', $data);