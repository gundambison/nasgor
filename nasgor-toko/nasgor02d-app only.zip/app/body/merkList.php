<?php
if(!checkLogin())
{
	redirect(my_url()."login");

}

$data=array(
'title'=>'merek produk',
'content'=>'merk/table_view',
'tab'=>array(),
'nav'=>array(),
'breadcrumb'=>'merek produk (merk)'
);

showView('index1_view', $data); 