<?php
$id=myUri(3);
$sql="select * from `".prefix()."payment` where payment_id='$id'";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
   $nm=str_replace("payment_","",$n  );
   $$nm=$v;
    
}

 
?>	<label>KODE</label>
	    <?=$code;?>
	<label>SALES</label>
	    <?=$sales;?>
	<label>NAMA</label>
	    <?=$nama;?>
	<label>VIA</label>
	    <?=$payto;?>
	<label>SEJUMLAH</label>
	    <?=$value;?><!--
	try fix this detail
-->
	<label>DESC</label>
	    <?=$Keterangan;?>