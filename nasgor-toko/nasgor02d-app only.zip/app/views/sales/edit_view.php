<form id='UpdateForm' style='margin:12px 20px'><?php
$id=myUri(3);
/*
Please edit the query
*/
$sql="select * from `".prefix()."sales`,
`".prefix()."salesdetail`
 where sales_id='$id' and
 salesdet_id = sales_id";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
	$nm=str_replace("sales_","",$n  );
	$$nm=$v;
	 
}
 

$det=json_decode($detail, true); ?><!-- <?php print_r($data);?>--><input type='hidden' name='sales_id' value='<?=$id;?>' />
	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='sales_code' value='<?=$code;?>' />
	<label type='num'>PELANGGAN</label>
	  <input type=text placeholder='Pelanggan' name='sales_customer' value='<?=$customer;?>' />
	<label type='date'>TANGGAL</label>
	  <input type=text placeholder='Tanggal' name='sales_date' value='<?=$date;?>' />
	<label type='num'>PEMBELIAN</label>
	  <input type=text placeholder='Pembelian' name='sales_shipp' value='<?=$shipp;?>' />
	<label type='num'>BIAYA</label>
	  <input type=text placeholder='Biaya' name='sales_cost' value='<?=$cost;?>' />
	<label type='num'>TOTAL</label>
	  <input type=text placeholder='Total' name='sales_total' value='<?=$total;?>' />
	<label type='num'>BERAT</label>
	  <input type=text placeholder='Berat' name='sales_weight' value='<?=$weight;?>' />
	<label type='num'>STATUS</label>
	  <input type=text placeholder='Status' name='sales_stat' value='<?=$stat;?>' />
	<label type='num'>DIBAYAR</label>
	  <input type=text placeholder='Dibayar' name='sales_payto' value='<?=$payto;?>' />
	<label type='num'>DIKIRIM</label>
	  <input type=text placeholder='Dikirim' name='sales_sendby' value='<?=$sendby;?>' />
	<label type='num'>TIPE</label>
	  <input type=text placeholder='Tipe' name='sales_type' value='<?=$type;?>' />
	<h3>DETAIL</h3>	<label type='chr'>NAMA DITUJU</label>
	  <input type=text placeholder='Nama Dituju' name='det[Keterangan]' value='<?=$det[Keterangan];?>' />
	<label type='text'>ALAMAT</label>
	  <input type=text placeholder='Alamat' name='det[Address]' value='<?=$det[Address];?>' />
	<label type='char'>KOTA</label>
	  <input type=text placeholder='Kota' name='det[City]' value='<?=$det[City];?>' />
	<label type='char'>KODEPOS</label>
	  <input type=text placeholder='Kodepos' name='det[CityCode]' value='<?=$det[CityCode];?>' />
	<label type='char'>DIKIRIM</label>
	  <input type=text placeholder='Dikirim' name='det[SendBy]' value='<?=$det[SendBy];?>' />
	<label type='num'>HARGA PERKILO</label>
	  <input type=text placeholder='Harga perkilo' name='det[Pricekg]' value='<?=$det[Pricekg];?>' />
	<label type='num'>POTONGAN</label>
	  <input type=text placeholder='Potongan' name='det[Discount]' value='<?=$det[Discount];?>' />
	<label type='text'>PESAN</label>
	  <input type=text placeholder='Pesan' name='det[Message]' value='<?=$det[Message];?>' />
	<label type='text'>KETERANGAN</label>
	  <input type=text placeholder='Keterangan' name='det[adminnote]' value='<?=$det[adminnote];?>' />	 
	<p><input type=button onclick='updateForm()' value='update' />
</form>