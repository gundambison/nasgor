<form id='UpdateForm' style='margin:12px 20px'><?php /* JUST EXAMPLE.. delete if you don't use this -->	
	<label>Code</label>
	<input type=text placeholder='Code' name='sales_code' value='<?php
$code=date("ymd");
$code.=sprintf("%04s",
	strtoupper(dechex(auto_id()%4000))
); 	
	echo $code;
	?>' readonly />
	 *jangan terlalu panjang*/ 
?>	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='sales_code' />
	<label type='num'>PELANGGAN</label>
	  <input type=text placeholder='Pelanggan' name='sales_customer' />
	<label type='date'>TANGGAL</label>
	  <input type=text placeholder='Tanggal' name='sales_date' />
	<label type='num'>PEMBELIAN</label>
	  <input type=text placeholder='Pembelian' name='sales_shipp' />
	<label type='num'>BIAYA</label>
	  <input type=text placeholder='Biaya' name='sales_cost' />
	<label type='num'>TOTAL</label>
	  <input type=text placeholder='Total' name='sales_total' />
	<label type='num'>BERAT</label>
	  <input type=text placeholder='Berat' name='sales_weight' />
	<label type='num'>STATUS</label>
	  <input type=text placeholder='Status' name='sales_stat' />
	<label type='num'>DIBAYAR</label>
	  <input type=text placeholder='Dibayar' name='sales_payto' />
	<label type='num'>DIKIRIM</label>
	  <input type=text placeholder='Dikirim' name='sales_sendby' />
	<label type='num'>TIPE</label>
	  <input type=text placeholder='Tipe' name='sales_type' />
	<h3>DETAIL</h3>	<label type='chr'>NAMA DITUJU</label>
	  <input type=text placeholder='Nama Dituju' name='det[Keterangan]'  />
	<label type='text'>ALAMAT</label>
	  <input type=text placeholder='Alamat' name='det[Address]'  />
	<label type='char'>KOTA</label>
	  <input type=text placeholder='Kota' name='det[City]'  />
	<label type='char'>KODEPOS</label>
	  <input type=text placeholder='Kodepos' name='det[CityCode]'  />
	<label type='char'>DIKIRIM</label>
	  <input type=text placeholder='Dikirim' name='det[SendBy]'  />
	<label type='num'>HARGA PERKILO</label>
	  <input type=text placeholder='Harga perkilo' name='det[Pricekg]'  />
	<label type='num'>POTONGAN</label>
	  <input type=text placeholder='Potongan' name='det[Discount]'  />
	<label type='text'>PESAN</label>
	  <input type=text placeholder='Pesan' name='det[Message]'  />
	<label type='text'>KETERANGAN</label>
	  <input type=text placeholder='Keterangan' name='det[adminnote]'  />
	<p><input type=button onclick='newData()' value='save' />
</form>
