<div style='padding:10px 5px'><a href="<?php echo my_url();?>">Home</a> - <?=$breadcrumb;?></div>
<?
/*
$siteUrl="http://".$_SERVER['SERVER_NAME']."/";
	$a=explode( "/",$_SERVER['SCRIPT_NAME']);
	for($i=0;$i<count($a)-1;$i++)
		$siteUrl.=$a[$i]."/";
echo $siteUrl;
 */
?>