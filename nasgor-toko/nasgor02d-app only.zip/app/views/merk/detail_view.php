<?php
$id=myUri(3);
$sql="select * from `".prefix()."merk` where merk_id='$id'";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
   $nm=str_replace("merk_","",$n  );
   $$nm=$v;
    
}

 
?>	<label>KODE</label>
	    <?=$code;?>
	<label>NAMA</label>
	    <?=$name;?>
	<label>STATUS</label>
	    <?=$stat;?><!--
	try fix this detail
-->
	<label>KETERANGAN</label>
	    <?=$desc;?>
	<label>ALAMAT</label>
	    <?=$address;?>
	<label>CP</label>
	    <?=$contact;?>