<form id='UpdateForm' style='margin:12px 20px'><?php
$id=myUri(3);
/*
Please edit the query
*/
$sql="select * from `".prefix()."merk`,
`".prefix()."merkdetail`
 where merk_id='$id' and
 merkdet_id = merk_id";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
	$nm=str_replace("merk_","",$n  );
	$$nm=$v;
	 
}
 

$det=json_decode($detail, true); ?><!-- <?php print_r($data);?>--><input type='hidden' name='merk_id' value='<?=$id;?>' />
	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='merk_code' value='<?=$code;?>' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='merk_name' value='<?=$name;?>' />
	<label type='txt'>STATUS</label>
	  <input type=text placeholder='Status' name='merk_stat' value='<?=$stat;?>' />
	<label type='txt'></label>
	  <input type=text placeholder='' name='merk_' value='<?=$;?>' />
	<h3>DETAIL</h3>	<label type='text'>KETERANGAN</label>
	  <input type=text placeholder='keterangan' name='det[desc]' value='<?=$det[desc];?>' />
	<label type='text'>ALAMAT</label>
	  <input type=text placeholder='alamat' name='det[address]' value='<?=$det[address];?>' />
	<label type='char'>CP</label>
	  <input type=text placeholder='CP' name='det[contact]' value='<?=$det[contact];?>' />	 
	<p><input type=button onclick='updateForm()' value='update' />
</form>