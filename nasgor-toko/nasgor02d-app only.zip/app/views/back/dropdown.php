<div class='col-md-3'>
      <div class="dropdown" role="navigation">
        <div class="well sidebar-nav">
          <ul class="nav">
            <li>Sidebar</li>
            <li class="active">
              <a href="#">Link</a>
            </li>
            <li>
              <a href="#">Link</a>
            </li>
            <li>
              <a href="#">Link</a>
            </li>
            <li>Sidebar</li>
            <li>
              <a href="#">Link</a>
            </li>
            <li>
              <a href="#">Link</a>
            </li>
            <li>
              <a href="#">Link</a>
            </li>
            <li>Sidebar</li>
            <li>
              <a href="#">Link</a>
            </li>
            <li>
              <a href="#">Link</a>
            </li>
          </ul>
        </div>
        <!--/.well -->
      </div>
    </div>
    