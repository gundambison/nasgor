<form id='UpdateForm' style='margin:12px 20px'><?php
$id=myUri(3);
/*
Please edit the query
*/
$sql="select * from `".prefix()."category`,
`".prefix()."categorydetail`
 where cat_id='$id' and
 catdet_id = cat_id";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
	$nm=str_replace("cat_","",$n  );
	$$nm=$v;
	 
}
 

$det=json_decode($detail, true); ?><!-- <?php print_r($data);?>--><input type='hidden' name='cat_id' value='<?=$id;?>' />
	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='cat_code' value='<?=$code;?>' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='cat_name' value='<?=$name;?>' />
	<label type='txt'>STATUS</label>
	  <input type=text placeholder='Status' name='cat_stat' value='<?=$stat;?>' />
	<label type='num'>PARENT</label>
	  <input type=text placeholder='Parent' name='cat_parent' value='<?=$parent;?>' />
	<label type='txt'>DETAIL</label>
	  <input type=text placeholder='Detail' name='cat_detail' value='<?=$detail;?>' />
	<h3>DETAIL</h3>	<label type='text'>DESC</label>
	  <input type=text placeholder='desc' name='det[Keterangan]' value='<?=$det[Keterangan];?>' />	 
	<p><input type=button onclick='updateForm()' value='update' />
</form>