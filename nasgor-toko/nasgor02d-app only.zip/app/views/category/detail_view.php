<?php
$id=myUri(3);
$sql="select * from `".prefix()."category` where cat_id='$id'";
$q=query($sql);
$data=fetch($q);
foreach($data as $n=>$v)
{
   $nm=str_replace("cat_","",$n  );
   $$nm=$v;
    
}

 
?>	<label>KODE</label>
	    <?=$code;?>
	<label>NAMA</label>
	    <?=$name;?>
	<label>STATUS</label>
	    <?=$stat;?>
	<label>PARENT</label>
	    <?=$parent;?><!--
	try fix this detail
-->
	<label>DESC</label>
	    <?=$Keterangan;?>