<form id='UpdateForm' style='margin:12px 20px'><?php /* JUST EXAMPLE.. delete if you don't use this -->	
	<label>Code</label>
	<input type=text placeholder='Code' name='cat_code' value='<?php
$code=date("ymd");
$code.=sprintf("%04s",
	strtoupper(dechex(auto_id()%4000))
); 	
	echo $code;
	?>' readonly />
	 *jangan terlalu panjang*/ 
?>	<label type='txt'>KODE</label>
	  <input type=text placeholder='Kode' name='cat_code' />
	<label type='txt'>NAMA</label>
	  <input type=text placeholder='Nama' name='cat_name' />
	<label type='txt'>STATUS</label>
	  <input type=text placeholder='Status' name='cat_stat' />
	<label type='num'>PARENT</label>
	  <input type=text placeholder='Parent' name='cat_parent' />
	<label type='txt'>DETAIL</label>
	  <input type=text placeholder='Detail' name='cat_detail' />
	<h3>DETAIL</h3>	<label type='text'>DESC</label>
	  <input type=text placeholder='desc' name='det[Keterangan]'  />
	<p><input type=button onclick='newData()' value='save' />
</form>
