<?php
$mods=array('database', 'session','myfunc','url','test_mod');
$lib=array('db'=>'database');