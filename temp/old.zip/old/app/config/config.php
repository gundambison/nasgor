<?php 
$siteUrl="http://localhost/nasgor1/";	
$baseBody="welcome";
/*
https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-prn2/1454604_10202000867537064_622573692_n.jpg
*/ 