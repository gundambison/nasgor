<?php
$data=array(
'title'=>'Welcome',
'content'=>'front'
 
);

showView('base_view', $data); 