<h1>ERROR</h1>
Mods tidak dapat di panggil <ol>
<?php
foreach($modsError as $v)
{
?><li><?=$v;?>.php</li>
<?php
}
?>
</ol>